using Microsoft.AspNetCore.Mvc;
using RaceDay.Web.Models;
using RaceDay.Web.Services;
namespace RaceDay.Web.Controllers;

public class HomeController : AppController
{
    private readonly IApiClient _api;
    public HomeController(IApiClient api) => _api = api;

    /// <summary>Landing page: upcoming events, straight from the API. Filtering arrives in the next chunk.</summary>
    public async Task<IActionResult> Index()
    {
        var result = await _api.GetAsync<List<EventSummary>>("api/events?upcomingOnly=true");
        return View(new HomeViewModel
        {
            Events = result.Data ?? new List<EventSummary>(),
            Error = result.Success ? null : result.Error
        });
    }

    /// <summary>Friendly error page for crashes (no code) and for 404 etc. (code from the status-code middleware).</summary>
    // The error page is re-run with the ORIGINAL request, which may be a POST that failed its
    // anti-forgery check, so this page must not demand a token itself.
    [IgnoreAntiforgeryToken]
    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error(int? code)
    {
        ViewData["Title"] = code == 404 ? "Page not found" : "Something went wrong";
        ViewData["Code"] = code;
        return View();
    }
}
