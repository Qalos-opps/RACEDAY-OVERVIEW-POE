using Microsoft.AspNetCore.Mvc;
using RaceDay.Web.Models;
using RaceDay.Web.Services;
namespace RaceDay.Web.Controllers;

/// <summary>Base class for every controller in the website: who is logged in, flash messages, expired logins.</summary>
public abstract class AppController : Controller
{
    /// <summary>The logged-in user, or null for a visitor.</summary>
    protected UserSession? CurrentUser => HttpContext.Session.GetUser();

    /// <summary>Shows a one-off green (success) or red (problem) message on the next page.</summary>
    protected void Flash(string message, bool success = true) =>
        TempData[success ? "Success" : "Error"] = message;

    /// <summary>Call when the API answers 401: the login there has expired, so start again from the login page.</summary>
    protected IActionResult SessionExpired()
    {
        HttpContext.Session.Clear();
        Flash("Your session has expired. Please log in again.", success: false);
        return RedirectToAction("Login", "Account", new { area = "" });
    }
}
