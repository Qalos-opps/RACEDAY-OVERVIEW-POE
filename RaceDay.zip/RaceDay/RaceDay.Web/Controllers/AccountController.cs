using Microsoft.AspNetCore.Mvc;
using RaceDay.Web.Models;
using RaceDay.Web.Services;
namespace RaceDay.Web.Controllers;

/// <summary>Register, log in, log out. All the real work (checking passwords, hashing) happens in the API.</summary>
public class AccountController : AppController
{
    private readonly IApiClient _api;
    public AccountController(IApiClient api) => _api = api;

    [HttpGet]
    public IActionResult Login(string? returnUrl = null)
    {
        if (CurrentUser is not null) return RedirectToAction("Index", "Home");
        return View(new LoginViewModel { ReturnUrl = returnUrl });
    }

    [HttpPost]
    public async Task<IActionResult> Login(LoginViewModel model)
    {
        if (!ModelState.IsValid) return View(model);

        // Start from a clean session, THEN call the API: the handler stores the API's login cookie
        // in the session during this call, so clearing afterwards would log the user straight out.
        HttpContext.Session.Clear();
        var result = await _api.PostAsync<UserSession>("api/auth/login", new { model.Email, model.Password });
        if (!result.Success || result.Data is null)
        {
            ModelState.AddModelError(string.Empty, result.Error ?? "We couldn't log you in. Please try again.");
            return View(model);
        }

        HttpContext.Session.SetUser(result.Data);
        Flash($"Welcome back, {result.Data.FirstName}!");

        // Next chunks: Organisers go to their dashboard, Participants stay on the events page.
        if (!string.IsNullOrEmpty(model.ReturnUrl) && Url.IsLocalUrl(model.ReturnUrl))
            return LocalRedirect(model.ReturnUrl);
        return RedirectToAction("Index", "Home");
    }

    [HttpGet]
    public IActionResult Register()
    {
        if (CurrentUser is not null) return RedirectToAction("Index", "Home");
        return View(new RegisterViewModel());
    }

    [HttpPost]
    public async Task<IActionResult> Register(RegisterViewModel model)
    {
        if (!ModelState.IsValid) return View(model);

        var result = await _api.PostAsync<UserSession>("api/auth/register",
            new { model.FirstName, model.LastName, model.Email, model.Password, model.PhoneNumber });
        if (!result.Success)
        {
            ModelState.AddModelError(string.Empty, result.Error ?? "We couldn't create your account. Please try again.");
            return View(model);
        }

        Flash("Your account has been created. Please log in.");
        return RedirectToAction(nameof(Login));
    }

    [HttpPost]
    public async Task<IActionResult> Logout()
    {
        if (CurrentUser is not null)
            await _api.PostAsync<object>("api/auth/logout"); // end the login on the API side too

        HttpContext.Session.Clear();
        Flash("You have been logged out.");
        return RedirectToAction("Index", "Home");
    }

    [HttpGet]
    public IActionResult AccessDenied() => View();
}
