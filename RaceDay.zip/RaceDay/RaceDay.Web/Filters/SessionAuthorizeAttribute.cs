using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using RaceDay.Web.Services;
namespace RaceDay.Web.Filters;

/// <summary>
/// Protects a controller or action using the session login.
/// [SessionAuthorize] = any logged-in user; [SessionAuthorize(Roles = "Organiser")] = that role only.
/// Logged-out visitors go to the login page; the wrong role goes to "access denied".
/// (The API checks the role again on every call, so this is for a good experience, not the only lock.)
/// </summary>
[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
public class SessionAuthorizeAttribute : Attribute, IAuthorizationFilter
{
    /// <summary>Comma-separated role names, e.g. "Organiser" or "Organiser,Participant".</summary>
    public string? Roles { get; set; }

    public void OnAuthorization(AuthorizationFilterContext context)
    {
        var user = context.HttpContext.Session.GetUser();
        if (user is null)
        {
            var request = context.HttpContext.Request;
            var returnUrl = request.Path + request.QueryString;
            context.Result = new RedirectToActionResult("Login", "Account", new { area = "", returnUrl });
            return;
        }

        if (!string.IsNullOrWhiteSpace(Roles))
        {
            var allowed = Roles.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
            if (!allowed.Contains(user.Role, StringComparer.OrdinalIgnoreCase))
                context.Result = new RedirectToActionResult("AccessDenied", "Account", new { area = "" });
        }
    }
}
