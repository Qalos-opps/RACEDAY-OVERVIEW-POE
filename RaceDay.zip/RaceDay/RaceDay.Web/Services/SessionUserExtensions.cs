using System.Text.Json;
using RaceDay.Web.Models;
namespace RaceDay.Web.Services;

/// <summary>Reads and writes the logged-in user's details (name, role, picture) in the session.</summary>
public static class SessionUserExtensions
{
    private const string UserKey = "user";
    private static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web);

    public static UserSession? GetUser(this ISession session)
    {
        var raw = session.GetString(UserKey);
        if (string.IsNullOrEmpty(raw)) return null;
        try
        {
            return JsonSerializer.Deserialize<UserSession>(raw, Json);
        }
        catch (JsonException)
        {
            return null;
        }
    }

    public static void SetUser(this ISession session, UserSession user) =>
        session.SetString(UserKey, JsonSerializer.Serialize(user, Json));
}
