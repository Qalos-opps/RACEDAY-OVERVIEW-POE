using System.Net;
namespace RaceDay.Web.Services;

/// <summary>What came back from an API call. Controllers check Success and show Error, so no raw error text reaches the user.</summary>
public class ApiResult
{
    public bool Success { get; init; }
    public HttpStatusCode StatusCode { get; init; }
    /// <summary>A short, user-friendly message when Success is false.</summary>
    public string? Error { get; init; }

    public bool IsUnauthorized => StatusCode == HttpStatusCode.Unauthorized;
    public bool IsForbidden => StatusCode == HttpStatusCode.Forbidden;
    public bool IsNotFound => StatusCode == HttpStatusCode.NotFound;
}

public class ApiResult<T> : ApiResult
{
    public T? Data { get; init; }
}
