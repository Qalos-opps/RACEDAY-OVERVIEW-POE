namespace RaceDay.Web.Services;

/// <summary>
/// The single doorway from the website to the RaceDay API. URLs are relative and have no leading
/// slash, e.g. "api/events". Use PostAsync&lt;object&gt; when the API sends nothing useful back.
/// </summary>
public interface IApiClient
{
    Task<ApiResult<T>> GetAsync<T>(string url, CancellationToken ct = default);
    Task<ApiResult<T>> PostAsync<T>(string url, object? body = null, CancellationToken ct = default);
    Task<ApiResult<T>> PutAsync<T>(string url, object? body = null, CancellationToken ct = default);
    Task<ApiResult> DeleteAsync(string url, CancellationToken ct = default);

    /// <summary>Sends an uploaded image to the API as multipart/form-data (the API stores it in Azure).</summary>
    Task<ApiResult<T>> PostFileAsync<T>(string url, IFormFile file, string fieldName = "file", CancellationToken ct = default);
}
