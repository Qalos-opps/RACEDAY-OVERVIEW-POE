namespace RaceDay.Web.Services;

/// <summary>Bound from the "ApiSettings" section of appsettings.json (or environment variables).</summary>
public class ApiSettings
{
    /// <summary>Where the Part 2 API is running. In Docker: ApiSettings__BaseUrl.</summary>
    public string BaseUrl { get; set; } = "https://localhost:61424";

    /// <summary>Accept the API's self-signed development certificate. Never enable this in production.</summary>
    public bool AllowUntrustedCertificate { get; set; }
}
