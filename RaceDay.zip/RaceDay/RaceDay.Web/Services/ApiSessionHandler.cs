using System.Globalization;
using System.Text.Json;
namespace RaceDay.Web.Services;

/// <summary>
/// The API remembers a logged-in user with a cookie. The browser never sees that cookie: this handler
/// keeps it in the visitor's server-side session and attaches it to every call this website makes to
/// the API on that visitor's behalf. That is how "session-based login" works across the two apps.
/// </summary>
public class ApiSessionHandler : DelegatingHandler
{
    private const string SessionKey = "api_cookies";
    private readonly IHttpContextAccessor _accessor;

    public ApiSessionHandler(IHttpContextAccessor accessor) => _accessor = accessor;

    protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
    {
        var session = _accessor.HttpContext?.Session;
        var cookies = new Dictionary<string, string>();

        if (session is not null)
        {
            await session.LoadAsync(cancellationToken);
            cookies = Load(session);
            if (cookies.Count > 0)
                request.Headers.TryAddWithoutValidation("Cookie", string.Join("; ", cookies.Select(c => $"{c.Key}={c.Value}")));
        }

        var response = await base.SendAsync(request, cancellationToken);

        // Login sets the cookie, logout (or an expired login) clears it, and the API refreshes it as it slides.
        if (session is not null && response.Headers.TryGetValues("Set-Cookie", out var setCookies))
        {
            foreach (var header in setCookies) Apply(cookies, header);
            session.SetString(SessionKey, JsonSerializer.Serialize(cookies));
        }
        return response;
    }

    private static Dictionary<string, string> Load(ISession session)
    {
        var raw = session.GetString(SessionKey);
        if (string.IsNullOrEmpty(raw)) return new Dictionary<string, string>();
        try
        {
            return JsonSerializer.Deserialize<Dictionary<string, string>>(raw) ?? new Dictionary<string, string>();
        }
        catch (JsonException)
        {
            return new Dictionary<string, string>();
        }
    }

    /// <summary>Reads one "Set-Cookie" header and adds, updates or removes the cookie.</summary>
    private static void Apply(Dictionary<string, string> cookies, string setCookieHeader)
    {
        var parts = setCookieHeader.Split(';').Select(p => p.Trim()).ToArray();
        var separator = parts[0].IndexOf('=');
        if (separator <= 0) return;

        var name = parts[0][..separator].Trim();
        var value = parts[0][(separator + 1)..].Trim();

        var expired = string.IsNullOrEmpty(value)
            || parts.Skip(1).Any(a => a.Equals("max-age=0", StringComparison.OrdinalIgnoreCase))
            || parts.Skip(1).Any(a => a.StartsWith("expires=", StringComparison.OrdinalIgnoreCase)
                && DateTimeOffset.TryParse(a["expires=".Length..], CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal, out var when)
                && when <= DateTimeOffset.UtcNow);

        if (expired) cookies.Remove(name);
        else cookies[name] = value;
    }
}
