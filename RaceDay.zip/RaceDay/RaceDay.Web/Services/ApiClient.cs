using System.Net;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
namespace RaceDay.Web.Services;

public class ApiClient : IApiClient
{
    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web);

    private readonly HttpClient _http;
    private readonly ILogger<ApiClient> _log;

    public ApiClient(HttpClient http, ILogger<ApiClient> log)
    {
        _http = http;
        _log = log;
    }

    public Task<ApiResult<T>> GetAsync<T>(string url, CancellationToken ct = default) =>
        SendAsync<T>(new HttpRequestMessage(HttpMethod.Get, url), ct);

    public Task<ApiResult<T>> PostAsync<T>(string url, object? body = null, CancellationToken ct = default) =>
        SendAsync<T>(WithJson(new HttpRequestMessage(HttpMethod.Post, url), body), ct);

    public Task<ApiResult<T>> PutAsync<T>(string url, object? body = null, CancellationToken ct = default) =>
        SendAsync<T>(WithJson(new HttpRequestMessage(HttpMethod.Put, url), body), ct);

    public async Task<ApiResult> DeleteAsync(string url, CancellationToken ct = default) =>
        await SendAsync<object>(new HttpRequestMessage(HttpMethod.Delete, url), ct);

    public Task<ApiResult<T>> PostFileAsync<T>(string url, IFormFile file, string fieldName = "file", CancellationToken ct = default)
    {
        var form = new MultipartFormDataContent();
        var fileContent = new StreamContent(file.OpenReadStream());
        if (MediaTypeHeaderValue.TryParse(file.ContentType, out var mediaType))
            fileContent.Headers.ContentType = mediaType;
        form.Add(fileContent, fieldName, Path.GetFileName(file.FileName));
        return SendAsync<T>(new HttpRequestMessage(HttpMethod.Post, url) { Content = form }, ct);
    }

    private static HttpRequestMessage WithJson(HttpRequestMessage request, object? body)
    {
        if (body is not null)
            request.Content = new StringContent(JsonSerializer.Serialize(body, body.GetType(), JsonOptions), Encoding.UTF8, "application/json");
        return request;
    }

    private async Task<ApiResult<T>> SendAsync<T>(HttpRequestMessage request, CancellationToken ct)
    {
        using (request)
        {
            try
            {
                using var response = await _http.SendAsync(request, ct);
                var status = response.StatusCode;
                var text = await response.Content.ReadAsStringAsync(ct);

                if (!response.IsSuccessStatusCode)
                    return new ApiResult<T> { Success = false, StatusCode = status, Error = FriendlyMessage(status, text) };

                T? data = default;
                if (!string.IsNullOrWhiteSpace(text))
                {
                    try
                    {
                        data = JsonSerializer.Deserialize<T>(text, JsonOptions);
                    }
                    catch (JsonException ex)
                    {
                        _log.LogWarning(ex, "Could not read the API reply for {Url}", request.RequestUri);
                        return new ApiResult<T> { Success = false, StatusCode = status, Error = "The RaceDay service sent a reply we could not read." };
                    }
                }
                return new ApiResult<T> { Success = true, StatusCode = status, Data = data };
            }
            catch (HttpRequestException ex)
            {
                _log.LogError(ex, "Could not reach the API at {Url}", request.RequestUri);
                return new ApiResult<T> { Success = false, StatusCode = HttpStatusCode.ServiceUnavailable, Error = "We couldn't reach the RaceDay service. Please try again shortly." };
            }
            catch (TaskCanceledException ex) when (!ct.IsCancellationRequested)
            {
                _log.LogError(ex, "The API timed out for {Url}", request.RequestUri);
                return new ApiResult<T> { Success = false, StatusCode = HttpStatusCode.GatewayTimeout, Error = "The RaceDay service took too long to respond. Please try again." };
            }
        }
    }

    /// <summary>
    /// Turns an API error reply into one short sentence. Understands our own { "message": "..." } replies
    /// and ASP.NET's validation replies ({ "errors": { "Field": ["..."] } }); anything else gets a generic line.
    /// </summary>
    private static string FriendlyMessage(HttpStatusCode status, string body)
    {
        if (!string.IsNullOrWhiteSpace(body))
        {
            try
            {
                using var doc = JsonDocument.Parse(body);
                var root = doc.RootElement;
                if (root.ValueKind == JsonValueKind.Object)
                {
                    if (root.TryGetProperty("message", out var message)
                        && message.ValueKind == JsonValueKind.String
                        && !string.IsNullOrWhiteSpace(message.GetString()))
                        return message.GetString()!;

                    if (root.TryGetProperty("errors", out var errors) && errors.ValueKind == JsonValueKind.Object)
                    {
                        var lines = errors.EnumerateObject()
                            .SelectMany(p => p.Value.ValueKind == JsonValueKind.Array
                                ? (IEnumerable<JsonElement>)p.Value.EnumerateArray()
                                : Enumerable.Empty<JsonElement>())
                            .Where(e => e.ValueKind == JsonValueKind.String)
                            .Select(e => e.GetString()!)
                            .Distinct()
                            .Take(3)
                            .ToList();
                        if (lines.Count > 0) return string.Join(" ", lines);
                    }
                }
            }
            catch (JsonException)
            {
                // Not JSON (e.g. an HTML error page): fall through to the generic message.
            }
        }

        return status switch
        {
            HttpStatusCode.Unauthorized => "Please log in to continue.",
            HttpStatusCode.Forbidden => "You don't have permission to do that.",
            HttpStatusCode.NotFound => "We couldn't find what you were looking for.",
            HttpStatusCode.Conflict => "That conflicts with something that already exists.",
            >= HttpStatusCode.InternalServerError => "Something went wrong on our side. Please try again.",
            _ => "That request couldn't be completed. Please check your details and try again."
        };
    }
}
