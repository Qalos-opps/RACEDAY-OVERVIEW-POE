namespace RaceDay.Web.Services;

/// <summary>Tiny display helpers shared by the views, so every page formats things the same way.</summary>
public static class UiHelpers
{
    /// <summary>Bootstrap Icons class for an event type.</summary>
    public static string TypeIcon(string? eventType) => (eventType ?? "").Trim().ToLowerInvariant() switch
    {
        "cycle" => "bi-bicycle",
        "walk" => "bi-person-walking",
        _ => "bi-lightning-charge-fill"
    };

    public static string Distance(decimal km) => $"{km:0.##} km";

    public static string ShortDate(DateTime date) => date.ToString("ddd, d MMM yyyy");
}
