using System.Text.Json.Serialization;
namespace RaceDay.Web.Models;

/// <summary>The logged-in user, as stored in the session. Matches the API's profile reply.</summary>
public record UserSession(int UserID, string FirstName, string LastName, string Email, string Role,
    string? PhoneNumber, string? ProfilePictureUrl)
{
    [JsonIgnore] public string FullName => $"{FirstName} {LastName}";
    [JsonIgnore] public bool IsOrganiser => string.Equals(Role, "Organiser", StringComparison.OrdinalIgnoreCase);
    [JsonIgnore] public bool IsParticipant => string.Equals(Role, "Participant", StringComparison.OrdinalIgnoreCase);
}
