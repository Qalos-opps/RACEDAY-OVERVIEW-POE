namespace RaceDay.Web.Models;

// Plain data shapes copied from the API's replies. No logic lives here: all rules stay in the API.

/// <summary>One event, as returned by GET api/events and GET api/events/{id}.</summary>
public record EventSummary(int EventID, int OrganiserID, string EventName, string? Description, string Location,
    DateTime EventDate, DateTime RegistrationDeadline, string Status, string EventType, decimal DistanceKm,
    string? BannerUrl);
