using System.Globalization;
using Microsoft.AspNetCore.Mvc;
using RaceDay.Web.Services;

// One culture everywhere (e.g. "21.1 km", "15 Nov 2026") so the site looks identical
// on a developer machine and inside a Docker container.
CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
CultureInfo.DefaultThreadCurrentUICulture = CultureInfo.InvariantCulture;

var builder = WebApplication.CreateBuilder(args);

// Every POST form is checked for an anti-forgery token automatically.
builder.Services.AddControllersWithViews(options =>
    options.Filters.Add(new AutoValidateAntiforgeryTokenAttribute()));

// Session: remembers who is logged in (and the API's login cookie) on the server.
builder.Services.AddHttpContextAccessor();
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(options =>
{
    options.Cookie.Name = "RaceDay.Session";
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
    options.IdleTimeout = TimeSpan.FromHours(8); // same as the API login cookie
});

// The ONLY way this website gets data: HTTP calls to the Part 2 API.
var api = builder.Configuration.GetSection("ApiSettings").Get<ApiSettings>() ?? new ApiSettings();
builder.Services.AddTransient<ApiSessionHandler>();
builder.Services.AddHttpClient<IApiClient, ApiClient>(client =>
{
    client.BaseAddress = new Uri(api.BaseUrl.TrimEnd('/') + "/");
    client.Timeout = TimeSpan.FromSeconds(30);
})
.ConfigurePrimaryHttpMessageHandler(() =>
{
    // UseCookies = false: cookies are kept per user in their own session (see ApiSessionHandler),
    // never in a cookie jar shared by every visitor.
    var handler = new HttpClientHandler { UseCookies = false, AllowAutoRedirect = false };
    // Only for Docker/local development, where the API's HTTPS dev certificate is not trusted.
    if (api.AllowUntrustedCertificate)
        handler.ServerCertificateCustomValidationCallback = HttpClientHandler.DangerousAcceptAnyServerCertificateValidator;
    return handler;
})
.AddHttpMessageHandler<ApiSessionHandler>();

var app = builder.Build();

// Friendly error pages instead of stack traces or blank 404s.
app.UseExceptionHandler("/Home/Error");
app.UseStatusCodePagesWithReExecute("/Home/Error", "?code={0}");
if (!app.Environment.IsDevelopment()) app.UseHsts();

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseSession();

// Organiser and Participant pages live in separate Areas (added in the next chunks).
app.MapControllerRoute(name: "areas", pattern: "{area:exists}/{controller=Home}/{action=Index}/{id?}");
app.MapControllerRoute(name: "default", pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
