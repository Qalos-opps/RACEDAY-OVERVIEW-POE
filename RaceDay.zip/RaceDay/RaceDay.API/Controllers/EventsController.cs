using System.Linq.Expressions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.API.Data;
using RaceDay.API.DTOs;
using RaceDay.API.Models;
namespace RaceDay.API.Controllers;

[ApiController, Route("api/events")]
public class EventsController : RaceDayControllerBase
{
    private static readonly string[] Statuses = { "Upcoming", "Open", "Closed", "Completed", "Cancelled" };
    private static readonly string[] EventTypes = { "Run", "Walk", "Cycle" };

    // One projection reused by the list and detail endpoints so they always return the same shape.
    private static readonly Expression<Func<Event, EventDto>> ToDto = e => new EventDto(
        e.EventID, e.OrganiserID, e.EventName, e.Description, e.Location, e.EventDate,
        e.RegistrationDeadline, e.Status, e.EventType, e.DistanceKm, e.BannerUrl);

    private readonly RaceDayDbContext _db;
    public EventsController(RaceDayDbContext db) => _db = db;

    /// <summary>Returns the canonical spelling of <paramref name="value"/> if it is in <paramref name="allowed"/>, otherwise null.</summary>
    private static string? Match(string[] allowed, string? value) =>
        allowed.FirstOrDefault(a => a.Equals(value?.Trim(), StringComparison.OrdinalIgnoreCase));

    /// <summary>Checks the rules shared by create and update. Returns an error message, or null when the request is valid.</summary>
    private static string? Validate(EventCreateRequest r, out string? status, out string? type)
    {
        status = Match(Statuses, r.Status);
        type = Match(EventTypes, r.EventType);
        if (type is null) return "Event type must be Run, Walk or Cycle.";
        if (status is null) return "Invalid event status.";
        if (r.RegistrationDeadline.Date > r.EventDate.Date) return "Registration must close on or before the event date.";
        return null;
    }

    /// <summary>Lists events. Optional filters: search text, event type, location, and upcomingOnly.</summary>
    [AllowAnonymous, HttpGet]
    [ProducesResponseType(typeof(List<EventDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> GetAll([FromQuery] string? search, [FromQuery] string? eventType,
        [FromQuery] string? location, [FromQuery] bool upcomingOnly = false)
    {
        var query = _db.Events.AsNoTracking();
        if (!string.IsNullOrWhiteSpace(search))
        {
            var s = search.Trim();
            query = query.Where(e => e.EventName.Contains(s) || (e.Description != null && e.Description.Contains(s)));
        }
        if (!string.IsNullOrWhiteSpace(location))
        {
            var l = location.Trim();
            query = query.Where(e => e.Location.Contains(l));
        }
        if (!string.IsNullOrWhiteSpace(eventType))
        {
            var t = Match(EventTypes, eventType);
            if (t is null) return BadRequest(new { message = "Event type must be Run, Walk or Cycle." });
            query = query.Where(e => e.EventType == t);
        }
        if (upcomingOnly)
        {
            var today = DateTime.Today;
            query = query.Where(e => e.EventDate >= today && e.Status != "Cancelled");
        }
        return Ok(await query.OrderBy(e => e.EventDate).Select(ToDto).ToListAsync());
    }

    /// <summary>Returns one event, including its type, distance and banner URL.</summary>
    [AllowAnonymous, HttpGet("{id:int}")]
    [ProducesResponseType(typeof(EventDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Get(int id)
    {
        var item = await _db.Events.AsNoTracking().Where(e => e.EventID == id).Select(ToDto).SingleOrDefaultAsync();
        return item is null ? NotFound(new { message = "Event not found." }) : Ok(item);
    }

    /// <summary>Organiser dashboard data: the logged-in Organiser's own events with category and enrolment counts.</summary>
    [Authorize(Roles = "Organiser"), HttpGet("mine")]
    [ProducesResponseType(typeof(List<OrganiserEventDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> Mine()
    {
        var organiserId = CurrentUserId;
        var events = await _db.Events.AsNoTracking()
            .Where(e => e.OrganiserID == organiserId)
            .OrderBy(e => e.EventDate)
            .Select(e => new OrganiserEventDto(
                e.EventID, e.EventName, e.Description, e.Location, e.EventDate, e.RegistrationDeadline, e.Status,
                e.EventType, e.DistanceKm, e.BannerUrl,
                e.Categories.Count(),
                e.Categories.SelectMany(c => c.Enrolments).Count(x => x.Status != "Cancelled")))
            .ToListAsync();
        return Ok(events);
    }

    /// <summary>Creates an event owned by the logged-in Organiser. Type must be Run, Walk or Cycle.</summary>
    [Authorize(Roles = "Organiser"), HttpPost]
    [ProducesResponseType(StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> Create(EventCreateRequest request)
    {
        var error = Validate(request, out var status, out var type);
        if (error is not null) return BadRequest(new { message = error });
        if (request.EventDate.Date < DateTime.Today) return BadRequest(new { message = "Event date must not be in the past." });

        var e = new Event
        {
            OrganiserID = CurrentUserId, EventName = request.EventName.Trim(), Description = request.Description?.Trim(),
            Location = request.Location.Trim(), EventDate = request.EventDate.Date,
            RegistrationDeadline = request.RegistrationDeadline.Date, Status = status!, EventType = type!,
            DistanceKm = request.DistanceKm, CreatedAt = DateTime.Now
        };
        _db.Events.Add(e);
        await _db.SaveChangesAsync();
        return CreatedAtAction(nameof(Get), new { id = e.EventID }, new { e.EventID, e.EventName });
    }

    /// <summary>Updates an event. Only the Organiser who created it may do this.</summary>
    [Authorize(Roles = "Organiser"), HttpPut("{id:int}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Update(int id, EventCreateRequest request)
    {
        var e = await _db.Events.FindAsync(id);
        if (e is null) return NotFound(new { message = "Event not found." });
        if (e.OrganiserID != CurrentUserId) return Forbidden("You can only change your own events.");

        var error = Validate(request, out var status, out var type);
        if (error is not null) return BadRequest(new { message = error });
        // A past date is only rejected when the Organiser is trying to MOVE the event into the past,
        // so a finished event can still be edited (e.g. marked Completed).
        if (request.EventDate.Date != e.EventDate.Date && request.EventDate.Date < DateTime.Today)
            return BadRequest(new { message = "Event date must not be moved into the past." });

        e.EventName = request.EventName.Trim(); e.Description = request.Description?.Trim(); e.Location = request.Location.Trim();
        e.EventDate = request.EventDate.Date; e.RegistrationDeadline = request.RegistrationDeadline.Date;
        e.Status = status!; e.EventType = type!; e.DistanceKm = request.DistanceKm;
        await _db.SaveChangesAsync();
        return Ok(new { e.EventID, e.EventName, e.Status });
    }

    /// <summary>Deletes an event. Only its owner may do this, and only if nobody has enrolled.</summary>
    [Authorize(Roles = "Organiser"), HttpDelete("{id:int}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Delete(int id)
    {
        var e = await _db.Events.FindAsync(id);
        if (e is null) return NotFound(new { message = "Event not found." });
        if (e.OrganiserID != CurrentUserId) return Forbidden("You can only delete your own events.");
        if (await _db.Enrolments.AnyAsync(x => x.Category!.EventID == id) || await _db.Weather.AnyAsync(w => w.EventID == id))
            return Conflict(new { message = "This event has enrolments or weather records and cannot be deleted." });
        // Categories have a restrict FK, so remove this event's (enrolment-free) categories first.
        var categories = await _db.Categories.Where(c => c.EventID == id).ToListAsync();
        _db.Categories.RemoveRange(categories);
        _db.Events.Remove(e);
        await _db.SaveChangesAsync();
        return NoContent();
    }

    /// <summary>Lists the categories of an event, including how many places are already taken.</summary>
    [AllowAnonymous, HttpGet("{eventId:int}/categories")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Categories(int eventId)
    {
        if (!await _db.Events.AnyAsync(e => e.EventID == eventId)) return NotFound(new { message = "Event not found." });
        return Ok(await _db.Categories.AsNoTracking().Where(c => c.EventID == eventId)
            .Select(c => new
            {
                c.CategoryID, c.EventID, c.CategoryName, c.DistanceKm, c.EntryFee, c.MaximumParticipants,
                SpotsTaken = c.Enrolments.Count(x => x.Status == "Active")
            }).ToListAsync());
    }

    /// <summary>Adds a category (e.g. "21km" or "Under 20") to an event the Organiser owns.</summary>
    [Authorize(Roles = "Organiser"), HttpPost("{eventId:int}/categories")]
    [ProducesResponseType(StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status409Conflict)]
    public async Task<IActionResult> AddCategory(int eventId, CategoryCreateRequest request)
    {
        var ev = await _db.Events.AsNoTracking().Where(e => e.EventID == eventId).Select(e => new { e.OrganiserID }).SingleOrDefaultAsync();
        if (ev is null) return NotFound(new { message = "Event not found." });
        if (ev.OrganiserID != CurrentUserId) return Forbidden("You can only add categories to your own events.");
        if (request.DistanceKm <= 0 || request.EntryFee < 0 || request.MaximumParticipants < 1)
            return BadRequest(new { message = "Distance and maximum participants must be positive; fee cannot be negative." });
        var name = request.CategoryName.Trim();
        if (await _db.Categories.AnyAsync(c => c.EventID == eventId && c.CategoryName == name))
            return Conflict(new { message = "This event already has a category with that name." });

        var c = new Category { EventID = eventId, CategoryName = name, DistanceKm = request.DistanceKm, EntryFee = request.EntryFee, MaximumParticipants = request.MaximumParticipants };
        _db.Categories.Add(c);
        await _db.SaveChangesAsync();
        return Created($"/api/events/{eventId}/categories", new { c.CategoryID, c.EventID, c.CategoryName });
    }

    /// <summary>Roster for one event: every participant who enrolled, with category, status and any recorded result. Owner only.</summary>
    [Authorize(Roles = "Organiser"), HttpGet("{eventId:int}/enrolments")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> EventEnrolments(int eventId)
    {
        var ev = await _db.Events.AsNoTracking().Where(e => e.EventID == eventId).Select(e => new { e.OrganiserID }).SingleOrDefaultAsync();
        if (ev is null) return NotFound(new { message = "Event not found." });
        if (ev.OrganiserID != CurrentUserId) return Forbidden("You can only view enrolments for your own events.");

        var list = await _db.Enrolments.AsNoTracking()
            .Where(x => x.Category!.EventID == eventId)
            .OrderBy(x => x.Category!.CategoryName).ThenBy(x => x.Participant!.LastName)
            .Select(x => new
            {
                x.EnrolmentID, x.EnrolmentDate, x.Status, x.EmergencyContact, x.CategoryID,
                CategoryName = x.Category!.CategoryName,
                ParticipantName = x.Participant!.FirstName + " " + x.Participant.LastName,
                ParticipantEmail = x.Participant.Email,
                ResultID = x.Result == null ? (int?)null : x.Result.ResultID,
                FinishTime = x.Result == null ? (TimeSpan?)null : x.Result.FinishTime,
                Position = x.Result == null ? (int?)null : x.Result.Position,
                ResultStatus = x.Result == null ? null : x.Result.ResultStatus
            }).ToListAsync();
        return Ok(list);
    }
}
