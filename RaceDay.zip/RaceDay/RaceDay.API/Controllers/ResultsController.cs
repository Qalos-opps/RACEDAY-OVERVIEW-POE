using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.API.Data;
using RaceDay.API.DTOs;
using RaceDay.API.Models;
namespace RaceDay.API.Controllers;

[ApiController, Route("api/results")]
public class ResultsController : RaceDayControllerBase
{
    private static readonly string[] ResultStatuses = { "Finished", "DNF", "DNS", "Disqualified" };

    private readonly RaceDayDbContext _db;
    public ResultsController(RaceDayDbContext db) => _db = db;

    /// <summary>Checks a result request. A "Finished" result needs a finish time and a position; other statuses store neither.</summary>
    private static string? Validate(ResultCreateRequest r, out string? status)
    {
        status = ResultStatuses.FirstOrDefault(s => s.Equals(r.ResultStatus?.Trim(), StringComparison.OrdinalIgnoreCase));
        if (status is null) return "Result status must be Finished, DNF, DNS or Disqualified.";
        if (status == "Finished")
        {
            if (r.FinishTime is null || r.FinishTime <= TimeSpan.Zero) return "A finish time is required for a finisher.";
            if (r.FinishTime >= TimeSpan.FromHours(24)) return "Finish time must be under 24 hours.";
            if (r.Position is null || r.Position < 1) return "A finishing position (1 or higher) is required for a finisher.";
        }
        return null;
    }

    /// <summary>Results may only be captured once the event has concluded (its date has arrived, or it is marked Completed).</summary>
    private static string? EventNotReady(Event ev)
    {
        if (ev.Status == "Cancelled") return "This event was cancelled, so results cannot be captured.";
        if (ev.Status != "Completed" && ev.EventDate.Date > DateTime.Today)
            return "Results can be captured once the event has concluded (its date has arrived or its status is Completed).";
        return null;
    }

    /// <summary>Records a finish time and position for an enrolment. Only the event's own Organiser may do this, after the event.</summary>
    [Authorize(Roles = "Organiser"), HttpPost]
    [ProducesResponseType(StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Create(ResultCreateRequest request)
    {
        var enrolment = await _db.Enrolments.Include(e => e.Category).ThenInclude(c => c!.Event)
            .SingleOrDefaultAsync(e => e.EnrolmentID == request.EnrolmentID);
        if (enrolment is null) return NotFound(new { message = "Enrolment not found." });
        var ev = enrolment.Category!.Event!;
        if (ev.OrganiserID != CurrentUserId) return Forbidden("You can only capture results for your own events.");
        if (enrolment.Status == "Cancelled") return BadRequest(new { message = "This enrolment was cancelled." });
        var notReady = EventNotReady(ev);
        if (notReady is not null) return BadRequest(new { message = notReady });
        var error = Validate(request, out var status);
        if (error is not null) return BadRequest(new { message = error });
        if (await _db.Results.AnyAsync(r => r.EnrolmentID == request.EnrolmentID)) return Conflict(new { message = "A result already exists for this enrolment." });
        if (status == "Finished" && await PositionTaken(enrolment.CategoryID, request.Position!.Value, 0))
            return Conflict(new { message = "That position is already taken in this category." });

        var result = new Result
        {
            EnrolmentID = request.EnrolmentID, ResultStatus = status!, RecordedAt = DateTime.UtcNow,
            FinishTime = status == "Finished" ? request.FinishTime : null,
            Position = status == "Finished" ? request.Position : null
        };
        _db.Results.Add(result);
        enrolment.Status = "Completed"; // the participant has now taken part
        await _db.SaveChangesAsync();
        return Created($"/api/results/{result.ResultID}", new { result.ResultID, result.EnrolmentID, result.FinishTime, result.Position, result.ResultStatus });
    }

    /// <summary>Corrects an existing result. Only the event's own Organiser may do this.</summary>
    [Authorize(Roles = "Organiser"), HttpPut("{id:int}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Update(int id, ResultCreateRequest request)
    {
        var result = await _db.Results.Include(r => r.Enrolment).ThenInclude(e => e!.Category).ThenInclude(c => c!.Event)
            .SingleOrDefaultAsync(r => r.ResultID == id);
        if (result is null) return NotFound(new { message = "Result not found." });
        var enrolment = result.Enrolment!;
        if (enrolment.Category!.Event!.OrganiserID != CurrentUserId) return Forbidden("You can only change results for your own events.");
        var error = Validate(request, out var status);
        if (error is not null) return BadRequest(new { message = error });
        if (status == "Finished" && await PositionTaken(enrolment.CategoryID, request.Position!.Value, id))
            return Conflict(new { message = "That position is already taken in this category." });

        result.ResultStatus = status!;
        result.FinishTime = status == "Finished" ? request.FinishTime : null;
        result.Position = status == "Finished" ? request.Position : null;
        await _db.SaveChangesAsync();
        return Ok(new { result.ResultID, result.EnrolmentID, result.FinishTime, result.Position, result.ResultStatus });
    }

    /// <summary>True when another finisher in the same category already holds this position.</summary>
    private Task<bool> PositionTaken(int categoryId, int position, int ignoreResultId) =>
        _db.Results.AnyAsync(r => r.ResultID != ignoreResultId && r.ResultStatus == "Finished"
            && r.Position == position && r.Enrolment!.CategoryID == categoryId);

    /// <summary>
    /// The logged-in Participant's race history: event, date, category, finish time, position and
    /// FinishersCount (how many people finished that category), e.g. "47th out of 312".
    /// </summary>
    [Authorize(Roles = "Participant"), HttpGet("me")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> Mine()
    {
        var id = CurrentUserId;
        return Ok(await _db.Results.AsNoTracking()
            .Where(r => r.Enrolment!.ParticipantID == id)
            .OrderByDescending(r => r.Enrolment!.Category!.Event!.EventDate)
            .Select(r => new
            {
                r.ResultID, r.FinishTime, r.Position, r.ResultStatus, r.RecordedAt,
                EventID = r.Enrolment!.Category!.EventID,
                EventName = r.Enrolment.Category.Event!.EventName,
                EventDate = r.Enrolment.Category.Event.EventDate,
                Location = r.Enrolment.Category.Event.Location,
                CategoryName = r.Enrolment.Category.CategoryName,
                FinishersCount = r.Enrolment.Category.Enrolments.Count(x => x.Result != null && x.Result.ResultStatus == "Finished")
            }).ToListAsync());
    }

    /// <summary>All results for one event, grouped by category and ordered by position. Only the event's own Organiser may view them.</summary>
    [Authorize(Roles = "Organiser"), HttpGet("/api/events/{eventId:int}/results")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> ForEvent(int eventId)
    {
        var ev = await _db.Events.AsNoTracking().Where(e => e.EventID == eventId).Select(e => new { e.OrganiserID }).SingleOrDefaultAsync();
        if (ev is null) return NotFound(new { message = "Event not found." });
        if (ev.OrganiserID != CurrentUserId) return Forbidden("You can only view results for your own events.");
        return Ok(await _db.Results.AsNoTracking()
            .Where(r => r.Enrolment!.Category!.EventID == eventId)
            .OrderBy(r => r.Enrolment!.Category!.CategoryName).ThenBy(r => r.Position ?? int.MaxValue)
            .Select(r => new
            {
                r.ResultID, r.EnrolmentID, r.FinishTime, r.Position, r.ResultStatus,
                CategoryName = r.Enrolment!.Category!.CategoryName,
                Participant = r.Enrolment.Participant!.FirstName + " " + r.Enrolment.Participant.LastName
            }).ToListAsync());
    }
}
