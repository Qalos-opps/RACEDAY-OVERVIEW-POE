using Azure;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RaceDay.API.Data;
using RaceDay.API.DTOs;
using RaceDay.API.Services;
namespace RaceDay.API.Controllers;

/// <summary>
/// Image uploads. The website posts the file here and this API stores it in Azure Blob Storage,
/// so the website never talks to Azure itself.
/// </summary>
[ApiController]
public class UploadsController : RaceDayControllerBase
{
    private const long MaxBannerBytes = 5 * 1024 * 1024;
    private const long MaxPictureBytes = 2 * 1024 * 1024;
    private const string StorageDown = "Image storage is not available right now. Please try again later.";

    private readonly RaceDayDbContext _db;
    private readonly IBlobStorageService _blobs;
    private readonly ILogger<UploadsController> _log;

    public UploadsController(RaceDayDbContext db, IBlobStorageService blobs, ILogger<UploadsController> log)
    {
        _db = db; _blobs = blobs; _log = log;
    }

    /// <summary>Uploads (or replaces) an event's banner image. JPG, PNG or WEBP, up to 5 MB. Only the event's owner may do this.</summary>
    /// <param name="id">The event ID.</param>
    /// <param name="file">The image, sent as multipart/form-data in a field called "file".</param>
    [Authorize(Roles = "Organiser"), HttpPost("api/events/{id:int}/banner")]
    [Consumes("multipart/form-data")]
    [RequestSizeLimit(7 * 1024 * 1024)]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
    public async Task<IActionResult> UploadBanner(int id, IFormFile? file)
    {
        var ev = await _db.Events.FindAsync(id);
        if (ev is null) return NotFound(new { message = "Event not found." });
        if (ev.OrganiserID != CurrentUserId) return Forbidden("You can only upload banners for your own events.");

        var check = await ImageValidator.CheckAsync(file, MaxBannerBytes);
        if (!check.Ok) return BadRequest(new { message = check.Error });

        string url;
        try
        {
            await using var stream = file!.OpenReadStream();
            url = await _blobs.UploadImageAsync(stream, $"events/{id}/{Guid.NewGuid():N}{check.Extension}", check.ContentType!);
        }
        catch (Exception ex) when (ex is RequestFailedException or InvalidOperationException or FormatException or ArgumentException)
        {
            _log.LogError(ex, "Banner upload failed for event {EventId}", id);
            return StatusCode(StatusCodes.Status503ServiceUnavailable, new { message = StorageDown });
        }

        var oldUrl = ev.BannerUrl;
        ev.BannerUrl = url;
        await _db.SaveChangesAsync();
        await _blobs.DeleteByUrlAsync(oldUrl); // tidy up the image we just replaced
        return Ok(new { bannerUrl = url });
    }

    /// <summary>Uploads (or replaces) the logged-in user's profile picture. JPG, PNG or WEBP, up to 2 MB.</summary>
    /// <param name="file">The image, sent as multipart/form-data in a field called "file".</param>
    [Authorize, HttpPost("api/users/me/picture")]
    [Consumes("multipart/form-data")]
    [RequestSizeLimit(4 * 1024 * 1024)]
    [ProducesResponseType(typeof(UserProfileDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
    public async Task<IActionResult> UploadProfilePicture(IFormFile? file)
    {
        var userId = CurrentUserId;
        var user = await _db.Users.FindAsync(userId);
        if (user is null) return NotFound(new { message = "User not found." });

        var check = await ImageValidator.CheckAsync(file, MaxPictureBytes);
        if (!check.Ok) return BadRequest(new { message = check.Error });

        string url;
        try
        {
            await using var stream = file!.OpenReadStream();
            url = await _blobs.UploadImageAsync(stream, $"profiles/{userId}/{Guid.NewGuid():N}{check.Extension}", check.ContentType!);
        }
        catch (Exception ex) when (ex is RequestFailedException or InvalidOperationException or FormatException or ArgumentException)
        {
            _log.LogError(ex, "Profile picture upload failed for user {UserId}", userId);
            return StatusCode(StatusCodes.Status503ServiceUnavailable, new { message = StorageDown });
        }

        var oldUrl = user.ProfilePictureUrl;
        user.ProfilePictureUrl = url;
        await _db.SaveChangesAsync();
        await _blobs.DeleteByUrlAsync(oldUrl);
        return Ok(new UserProfileDto(user.UserID, user.FirstName, user.LastName, user.Email, user.Role, user.PhoneNumber, user.ProfilePictureUrl));
    }
}
