using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.API.Data;
using RaceDay.API.DTOs;
using RaceDay.API.Models;
namespace RaceDay.API.Controllers;

[ApiController, Route("api/enrolments"), Authorize(Roles = "Participant")]
public class EnrolmentsController : RaceDayControllerBase
{
    private readonly RaceDayDbContext _db;
    public EnrolmentsController(RaceDayDbContext db) => _db = db;

    /// <summary>Enrols the logged-in Participant in a category. Fails if registration is closed, the category is full, or they are already in it.</summary>
    [HttpPost]
    [ProducesResponseType(StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Create(EnrolmentCreateRequest request)
    {
        var participantId = CurrentUserId;
        var category = await _db.Categories.Include(c => c.Event).SingleOrDefaultAsync(c => c.CategoryID == request.CategoryID);
        if (category is null) return NotFound(new { message = "Category not found." });
        if (category.Event!.RegistrationDeadline.Date < DateTime.Today || category.Event.Status != "Open") return BadRequest(new { message = "Registration is closed for this event." });
        if (await _db.Enrolments.AnyAsync(e => e.ParticipantID == participantId && e.CategoryID == request.CategoryID)) return Conflict(new { message = "You are already enrolled in this category." });
        if (await _db.Enrolments.CountAsync(e => e.CategoryID == request.CategoryID && e.Status == "Active") >= category.MaximumParticipants) return Conflict(new { message = "This category is full." });
        var enrolment = new Enrolment { ParticipantID = participantId, CategoryID = request.CategoryID, EmergencyContact = request.EmergencyContact.Trim(), EnrolmentDate = DateTime.UtcNow, Status = "Active" };
        _db.Enrolments.Add(enrolment);
        await _db.SaveChangesAsync();
        return Created($"/api/enrolments/{enrolment.EnrolmentID}", new { enrolment.EnrolmentID, enrolment.CategoryID, enrolment.Status });
    }

    /// <summary>The logged-in Participant's own enrolments, newest event first, with event details and any result.</summary>
    [HttpGet("me")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> Mine()
    {
        var id = CurrentUserId;
        return Ok(await _db.Enrolments.AsNoTracking()
            .Where(e => e.ParticipantID == id)
            .OrderByDescending(e => e.Category!.Event!.EventDate)
            .Select(e => new
            {
                e.EnrolmentID, e.EnrolmentDate, e.Status, e.CategoryID,
                Category = e.Category!.CategoryName,
                EventID = e.Category.EventID,
                Event = e.Category.Event!.EventName,
                EventDate = e.Category.Event.EventDate,
                Location = e.Category.Event.Location,
                EventType = e.Category.Event.EventType,
                BannerUrl = e.Category.Event.BannerUrl,
                Result = e.Result == null ? null : new { e.Result.ResultID, e.Result.FinishTime, e.Result.Position, e.Result.ResultStatus }
            }).ToListAsync());
    }

    /// <summary>Cancels one of the logged-in Participant's own enrolments.</summary>
    [HttpDelete("{id:int}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Cancel(int id)
    {
        var participantId = CurrentUserId;
        var e = await _db.Enrolments.SingleOrDefaultAsync(x => x.EnrolmentID == id && x.ParticipantID == participantId);
        if (e is null) return NotFound(new { message = "Enrolment not found." });
        e.Status = "Cancelled";
        await _db.SaveChangesAsync();
        return NoContent();
    }
}
