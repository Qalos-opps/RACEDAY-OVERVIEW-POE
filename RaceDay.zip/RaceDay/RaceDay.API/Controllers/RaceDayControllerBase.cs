using System.Security.Claims;
using Microsoft.AspNetCore.Mvc;
namespace RaceDay.API.Controllers;

/// <summary>Small helpers shared by the controllers that need to know who is logged in.</summary>
public abstract class RaceDayControllerBase : ControllerBase
{
    /// <summary>The UserID stored in the login cookie. Only call this from [Authorize]d actions.</summary>
    protected int CurrentUserId => int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)!.Value);

    /// <summary>403 with a JSON message, used when a logged-in Organiser touches someone else's data.</summary>
    protected ObjectResult Forbidden(string message) =>
        StatusCode(StatusCodes.Status403Forbidden, new { message });
}
