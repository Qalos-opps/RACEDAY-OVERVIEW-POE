using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.API.Data;
using RaceDay.API.DTOs;
namespace RaceDay.API.Controllers;

[ApiController, Route("api/categories")]
public class CategoriesController : RaceDayControllerBase
{
    private readonly RaceDayDbContext _db;
    public CategoriesController(RaceDayDbContext db) => _db = db;

    /// <summary>Updates a category. Only the Organiser who owns the event may do this.</summary>
    [Authorize(Roles = "Organiser"), HttpPut("{id:int}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Update(int id, CategoryCreateRequest request)
    {
        var c = await _db.Categories.Include(x => x.Event).SingleOrDefaultAsync(x => x.CategoryID == id);
        if (c is null) return NotFound(new { message = "Category not found." });
        if (c.Event!.OrganiserID != CurrentUserId) return Forbidden("You can only change categories on your own events.");
        if (request.DistanceKm <= 0 || request.EntryFee < 0 || request.MaximumParticipants < 1)
            return BadRequest(new { message = "Distance and maximum participants must be positive; fee cannot be negative." });
        var name = request.CategoryName.Trim();
        if (await _db.Categories.AnyAsync(x => x.EventID == c.EventID && x.CategoryName == name && x.CategoryID != id))
            return Conflict(new { message = "This event already has a category with that name." });

        c.CategoryName = name; c.DistanceKm = request.DistanceKm; c.EntryFee = request.EntryFee; c.MaximumParticipants = request.MaximumParticipants;
        await _db.SaveChangesAsync();
        return Ok(new { c.CategoryID, c.EventID, c.CategoryName });
    }

    /// <summary>Deletes a category. Only the event's Organiser may do this, and only if nobody has enrolled in it.</summary>
    [Authorize(Roles = "Organiser"), HttpDelete("{id:int}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Delete(int id)
    {
        var c = await _db.Categories.Include(x => x.Event).SingleOrDefaultAsync(x => x.CategoryID == id);
        if (c is null) return NotFound(new { message = "Category not found." });
        if (c.Event!.OrganiserID != CurrentUserId) return Forbidden("You can only delete categories on your own events.");
        if (await _db.Enrolments.AnyAsync(e => e.CategoryID == id)) return Conflict(new { message = "Cannot delete a category with enrolments." });
        _db.Categories.Remove(c);
        await _db.SaveChangesAsync();
        return NoContent();
    }
}
