using System.Text;
namespace RaceDay.API.Services;

/// <summary>Outcome of checking an uploaded file.</summary>
public record ImageCheck(bool Ok, string? Error, string? ContentType, string? Extension)
{
    public static ImageCheck Fail(string error) => new(false, error, null, null);
    public static ImageCheck Pass(string contentType, string extension) => new(true, null, contentType, extension);
}

/// <summary>
/// Decides what an uploaded file really is by reading its first bytes, not by trusting the
/// file name or the Content-Type the client sent. Only JPG, PNG and WEBP are accepted.
/// </summary>
public static class ImageValidator
{
    private static readonly byte[] PngSignature = { 0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A };

    public static async Task<ImageCheck> CheckAsync(IFormFile? file, long maxBytes)
    {
        if (file is null || file.Length == 0) return ImageCheck.Fail("Please choose an image file.");
        if (file.Length > maxBytes) return ImageCheck.Fail($"The image is too large. The limit is {maxBytes / (1024 * 1024)} MB.");

        var header = new byte[12];
        await using var stream = file.OpenReadStream();
        var read = await stream.ReadAtLeastAsync(header, header.Length, throwOnEndOfStream: false);
        if (read < header.Length) return ImageCheck.Fail("That file is not a valid image.");

        if (header[0] == 0xFF && header[1] == 0xD8 && header[2] == 0xFF) return ImageCheck.Pass("image/jpeg", ".jpg");
        if (header.Take(PngSignature.Length).SequenceEqual(PngSignature)) return ImageCheck.Pass("image/png", ".png");
        if (Encoding.ASCII.GetString(header, 0, 4) == "RIFF" && Encoding.ASCII.GetString(header, 8, 4) == "WEBP")
            return ImageCheck.Pass("image/webp", ".webp");

        return ImageCheck.Fail("Only JPG, PNG or WEBP images are allowed.");
    }
}
