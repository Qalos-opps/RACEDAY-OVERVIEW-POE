using Azure;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Microsoft.Extensions.Options;
namespace RaceDay.API.Services;

/// <summary>Settings read from the "AzureBlob" section of appsettings / user secrets / environment variables.</summary>
public class BlobStorageOptions
{
    /// <summary>"UseDevelopmentStorage=true" for the Azurite emulator, or your real Azure Storage connection string.</summary>
    public string ConnectionString { get; set; } = "";
    public string ContainerName { get; set; } = "raceday-images";
}

/// <summary>The only place in the whole solution that talks to Azure Blob Storage.</summary>
public interface IBlobStorageService
{
    /// <summary>Uploads an image and returns its public URL.</summary>
    Task<string> UploadImageAsync(Stream content, string blobPath, string contentType, CancellationToken ct = default);

    /// <summary>Best-effort delete of an image we uploaded earlier (used when an image is replaced). Never throws.</summary>
    Task DeleteByUrlAsync(string? blobUrl, CancellationToken ct = default);
}

public class BlobStorageService : IBlobStorageService
{
    private readonly BlobStorageOptions _options;
    private readonly ILogger<BlobStorageService> _log;
    private readonly SemaphoreSlim _setupLock = new(1, 1);
    private BlobContainerClient? _container;

    public BlobStorageService(IOptions<BlobStorageOptions> options, ILogger<BlobStorageService> log)
    {
        _options = options.Value;
        _log = log;
    }

    // The container is created (once) the first time it is needed, so the API still starts
    // and every non-upload endpoint still works when storage is not configured yet.
    private async Task<BlobContainerClient> GetContainerAsync(CancellationToken ct)
    {
        if (_container is not null) return _container;
        await _setupLock.WaitAsync(ct);
        try
        {
            if (_container is not null) return _container;
            if (string.IsNullOrWhiteSpace(_options.ConnectionString))
                throw new InvalidOperationException("AzureBlob:ConnectionString is not configured.");

            var client = new BlobContainerClient(_options.ConnectionString, _options.ContainerName);
            try
            {
                // Public read access on blobs, so the browser can show the image straight from its URL.
                await client.CreateIfNotExistsAsync(PublicAccessType.Blob, cancellationToken: ct);
                await client.SetAccessPolicyAsync(PublicAccessType.Blob, cancellationToken: ct);
            }
            catch (RequestFailedException ex) when (ex.ErrorCode == "PublicAccessNotPermitted")
            {
                throw new InvalidOperationException(
                    "The storage account does not allow public blob access. In the Azure portal open the storage account, " +
                    "go to Configuration, set 'Allow Blob anonymous access' to Enabled, then try again.", ex);
            }
            _container = client;
            return client;
        }
        finally
        {
            _setupLock.Release();
        }
    }

    public async Task<string> UploadImageAsync(Stream content, string blobPath, string contentType, CancellationToken ct = default)
    {
        var container = await GetContainerAsync(ct);
        var blob = container.GetBlobClient(blobPath);
        await blob.UploadAsync(content, new BlobUploadOptions
        {
            // Blob names contain a random GUID and are never overwritten, so long caching is safe.
            HttpHeaders = new BlobHttpHeaders { ContentType = contentType, CacheControl = "public, max-age=31536000" }
        }, ct);
        return blob.Uri.ToString();
    }

    public async Task DeleteByUrlAsync(string? blobUrl, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(blobUrl) || !Uri.TryCreate(blobUrl, UriKind.Absolute, out var uri)) return;
        try
        {
            var container = await GetContainerAsync(ct);
            var parts = new BlobUriBuilder(uri);
            // Only ever delete blobs that live in OUR container.
            if (!string.Equals(parts.BlobContainerName, container.Name, StringComparison.Ordinal)
                || string.IsNullOrEmpty(parts.BlobName)) return;
            await container.DeleteBlobIfExistsAsync(parts.BlobName, cancellationToken: ct);
        }
        catch (Exception ex)
        {
            _log.LogWarning(ex, "Could not delete the old image {Url}", blobUrl);
        }
    }
}
