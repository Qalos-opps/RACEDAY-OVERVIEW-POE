using System.ComponentModel.DataAnnotations;
namespace RaceDay.API.DTOs;

public record EventCreateRequest(
    [Required, MaxLength(100)] string EventName,
    [MaxLength(500)] string? Description,
    [Required, MaxLength(150)] string Location,
    DateTime EventDate, DateTime RegistrationDeadline,
    [Required, MaxLength(20)] string EventType,
    [Range(0.01, 1000)] decimal DistanceKm,
    [Required] string Status = "Upcoming");

/// <summary>An event as returned by the public event endpoints.</summary>
public record EventDto(
    int EventID, int OrganiserID, string EventName, string? Description, string Location,
    DateTime EventDate, DateTime RegistrationDeadline, string Status,
    string EventType, decimal DistanceKm, string? BannerUrl);

/// <summary>An event plus counts, for the Organiser dashboard.</summary>
public record OrganiserEventDto(
    int EventID, string EventName, string? Description, string Location,
    DateTime EventDate, DateTime RegistrationDeadline, string Status,
    string EventType, decimal DistanceKm, string? BannerUrl,
    int CategoryCount, int EnrolmentCount);

public record CategoryCreateRequest(
    [Required, MaxLength(100)] string CategoryName,
    decimal DistanceKm, decimal EntryFee, int MaximumParticipants);

public record EnrolmentCreateRequest(
    int CategoryID, [Required, MaxLength(100)] string EmergencyContact);

public record ResultCreateRequest(
    int EnrolmentID, TimeSpan? FinishTime, int? Position, string ResultStatus = "Finished");
