/* ============================================================
   RaceDay - Part 3 database update
   Run ONCE in SSMS against your existing RaceDay database.
   Safe to re-run: every step checks whether it is already done.
   Adds: Events.EventType, Events.DistanceKm, Events.BannerUrl,
         Users.ProfilePictureUrl (+ check constraints).
   ============================================================ */
USE RaceDay;
GO

/* --- 1. New columns (existing rows get the default shown) --- */
IF COL_LENGTH('Events', 'EventType') IS NULL
    ALTER TABLE Events ADD EventType NVARCHAR(20) NOT NULL
        CONSTRAINT DF_Events_EventType DEFAULT 'Run';

IF COL_LENGTH('Events', 'DistanceKm') IS NULL
    ALTER TABLE Events ADD DistanceKm DECIMAL(6,2) NOT NULL
        CONSTRAINT DF_Events_DistanceKm DEFAULT 10;

IF COL_LENGTH('Events', 'BannerUrl') IS NULL
    ALTER TABLE Events ADD BannerUrl NVARCHAR(500) NULL;

IF COL_LENGTH('Users', 'ProfilePictureUrl') IS NULL
    ALTER TABLE Users ADD ProfilePictureUrl NVARCHAR(500) NULL;
GO

/* --- 2. Constraints (separate batch: the columns must exist first) --- */
IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'CK_Events_EventType')
    ALTER TABLE Events ADD CONSTRAINT CK_Events_EventType
        CHECK (EventType IN ('Run', 'Walk', 'Cycle'));

IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'CK_Events_Distance')
    ALTER TABLE Events ADD CONSTRAINT CK_Events_Distance
        CHECK (DistanceKm > 0);
GO

/* --- 3. Tidy up your existing sample events ---
   a) Give each event the distance of its longest category. */
UPDATE e
SET    e.DistanceKm = x.MaxKm
FROM   Events e
CROSS APPLY (SELECT MAX(c.DistanceKm) AS MaxKm
             FROM Categories c
             WHERE c.EventID = e.EventID) x
WHERE  x.MaxKm IS NOT NULL;
GO

/* b) Set the correct type for any event that is not a run, e.g.:
      UPDATE Events SET EventType = 'Cycle' WHERE EventName LIKE '%Cycle%';
      UPDATE Events SET EventType = 'Walk'  WHERE EventName LIKE '%Walk%';
   Then check the result: */
SELECT EventID, EventName, EventType, DistanceKm, BannerUrl FROM Events;
GO
