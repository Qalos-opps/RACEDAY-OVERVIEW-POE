# Chunk 3 - The MVC website (skeleton)

New project `RaceDay.Web` + `RaceDay.sln`. Nothing in the API changed.

## Run it
1. Open `RaceDay.sln`. Right-click the solution > **Configure Startup Projects** > **Multiple startup projects** > set **RaceDay.API** and **RaceDay.Web** to **Start**. Press play.
2. The API opens on https://localhost:61424/swagger and the website on https://localhost:61500.
3. If the website shows "couldn't reach the RaceDay service", the API isn't running or the port in `RaceDay.Web/appsettings.json` (`ApiSettings:BaseUrl`) is different from yours.

## Test checklist
- Home page lists upcoming events from the API. If it says "No upcoming events yet", your sample events have past dates. Run in SSMS:
  ```sql
  UPDATE Events SET EventDate = DATEADD(day, 30, GETDATE()),
                    RegistrationDeadline = DATEADD(day, 20, GETDATE()),
                    Status = 'Open';
  ```
- **Join RaceDay**: register a new participant. Try a short password and mismatched passwords: you should see friendly messages.
- Register the same email again: "Email is already registered."
- **Log in**: wrong password gives "Email or password is incorrect." Right password shows your name and a role chip in the menu.
- Log in with a seeded **Organiser** account: the chip says ORGANISER.
- **Log out** from the menu, then you are back on the home page, logged out.
- Stop the API and refresh the home page: a friendly warning, not a crash.
- Visit https://localhost:61500/nothing: friendly "Off the course" page.

## How it works (for your video)
- The website has **no database code**. `Services/ApiClient.cs` is its only way to get data: it calls the API over HTTP and returns an `ApiResult` (success, data, or a friendly error).
- **Session login across two apps:** the API logs a user in with a cookie. `Services/ApiSessionHandler.cs` catches that cookie and keeps it in the visitor's *server-side session*; the browser never sees it. On every later call it attaches that visitor's cookie. The user's name and role are also kept in the session (`SessionUserExtensions`).
- `Filters/SessionAuthorizeAttribute.cs`: put `[SessionAuthorize]` (any user) or `[SessionAuthorize(Roles = "Organiser")]` on a controller. Logged-out visitors go to login; the wrong role gets "Access denied". The API checks roles again on every call.
- `UseCookies = false` on the HTTP handler matters: otherwise every visitor would share one cookie jar.
- Anti-forgery tokens are checked on every POST form. Errors become friendly pages (`Home/Error`).
- All colours, fonts and components live in `wwwroot/css/site.css`, so every page looks the same. `_StatusBadge` is the single colour-coded status pill.
- One culture (invariant) is set so numbers and dates look the same on your PC and inside Docker.

## Coming next
- Chunk 4: Participant pages (filters, event details, enrol, My Enrolments, My Results, Profile + picture).
- Chunk 5: Organiser pages (dashboard, events + banner upload, categories, enrolments, results entry).
- Chunk 6: Dockerfile, README, GitHub Actions to build both projects. For Docker the API address is set with the environment variable `ApiSettings__BaseUrl`, plus `ApiSettings__AllowUntrustedCertificate=true` because the API's development certificate is not trusted inside a container.
- This code is syntax-checked only. I could not compile it here.
