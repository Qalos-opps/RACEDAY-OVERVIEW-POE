# Chunk 1 - API changes for Part 3

## How to apply
1. Copy the `RaceDay.API` folder from this zip over your project (replace files when asked).
   `RaceDayControllerBase.cs` is new. Nothing else in your project changes.
2. Open `docs/RACEDAY_Part3_Update.sql` in SSMS and run it once (adds the new columns).
3. Rebuild in Visual Studio and test in Swagger. Send me any red errors.

## What changed
| Area | Change |
|---|---|
| Event | New fields `EventType` (Run/Walk/Cycle), `DistanceKm`, `BannerUrl` |
| User | New field `ProfilePictureUrl` (returned by login and `/api/users/me`) |
| `GET /api/events` | Optional filters: `?search=&eventType=&location=&upcomingOnly=true` |
| `GET /api/events/mine` | NEW (Organiser): own events with category + enrolment counts |
| `GET /api/events/{id}/enrolments` | NEW (Organiser, owner only): roster with category, status, result |
| `GET /api/events/{id}/categories` | Now includes `SpotsTaken` |
| Events / Categories / Results | Owner check: an Organiser can only change their own events' data (403 otherwise) |
| `GET /api/enrolments/me` | Adds event id, date, location, type, banner |
| `GET /api/results/me` | Adds event date, location, category and `FinishersCount` ("47th of 312") |

## Behaviour changes to know about
- Creating/updating an event now needs `eventType` and `distanceKm` in the JSON body.
- A past event can be edited (e.g. set to Completed); only moving it INTO the past is blocked.
- Results can only be captured once the event date has arrived or its status is Completed.
- A Finished result needs a finish time (< 24h) and a position; positions are unique per category.
- Capturing a result sets that enrolment's status to Completed.
- `PUT /api/categories/{id}` and `PUT /api/results/{id}` now return 200 with a body; `POST /api/results` returns 201 (matches your endpoint plan).
- Deleting an event with no enrolments now also removes its empty categories (before, this failed with a database error).
- Duplicate category names on one event return 409 instead of a database error.
- Not changed: registration still creates Participants only; Organisers are seeded.

## Add to your endpoint plan (docs)
| Method | Route | Role | Description |
|---|---|---|---|
| GET | `/api/events/mine` | Organiser | Own events with counts (dashboard) |
| POST | `/api/events/{id}/banner` | Organiser | Upload banner image (chunk 2) |
| POST | `/api/users/me/picture` | Any logged-in | Upload profile picture (chunk 2) |
| POST | `/api/auth/logout` | Any logged-in | Ends the session (already built, missing from plan) |

## Still open
- Your project has no `Migrations` folder (the database comes from the SQL script), but the Part 2 brief says Code-First. Decide later whether to switch to EF migrations.
- Part 2 gaps from the audit (unit tests, GitHub Actions, README, .gitignore, Swagger descriptions) are still to do.
- This code is syntax-checked only. I could not compile it here.
