# Chunk 2 - Azure Blob Storage (images)

Needs chunk 1 applied first (it added `Event.BannerUrl` and `User.ProfilePictureUrl`).

## How to apply
1. Copy the `RaceDay.API` folder from this zip over your project.
   - NEW: `Services/BlobStorageService.cs`, `Services/ImageValidator.cs`, `Controllers/UploadsController.cs`
   - REPLACED: `Program.cs` and `RaceDay.API.csproj`. If you edited either since sending me the project, merge by hand. The changes are: the `Azure.Storage.Blobs` package, `GenerateDocumentationFile`, the Swagger XML-comments block, and the two `BlobStorage` lines in Program.cs.
2. Add this block to your `appsettings.json` (next to `ConnectionStrings`; do NOT put a real Azure key in this file):
   ```json
   "AzureBlob": {
     "ConnectionString": "UseDevelopmentStorage=true",
     "ContainerName": "raceday-images"
   },
   ```
3. Start a storage back end (pick ONE):

   **A. Azurite, the free local emulator (easiest, no Azure account):**
   ```
   docker run -d --name azurite -p 10000:10000 mcr.microsoft.com/azure-storage/azurite azurite-blob --blobHost 0.0.0.0 --skipApiVersionCheck
   ```
   Leave the connection string as `UseDevelopmentStorage=true`.

   **B. Real Azure Storage:**
   1. Azure portal > Storage accounts > Create (Standard, LRS, any nearby region).
   2. Open the account > Configuration > set **Allow Blob anonymous access** to **Enabled** > Save.
   3. Security + networking > Access keys > copy a **Connection string**.
   4. In Visual Studio: right-click `RaceDay.API` > **Manage User Secrets** and paste:
      ```json
      { "AzureBlob": { "ConnectionString": "<your connection string>" } }
      ```
      User secrets stay on your computer, so the key never reaches GitHub. Never commit the key.
4. Rebuild and run.

## Try it in Swagger
1. `POST /api/auth/login` as an Organiser.
2. `POST /api/events/{id}/banner`: pick an event you own, choose a JPG/PNG/WEBP file, Execute. You get `{ "bannerUrl": "..." }`. Paste the URL in a browser tab; the image should show.
3. Log in as any user and try `POST /api/users/me/picture` the same way.
4. `GET /api/events/{id}` now returns the `bannerUrl`.

## New endpoints
| Method | Route | Role | Notes |
|---|---|---|---|
| POST | `/api/events/{id}/banner` | Organiser (event owner) | multipart field `file`, max 5 MB. Returns `{ bannerUrl }` |
| POST | `/api/users/me/picture` | Any logged-in user | multipart field `file`, max 2 MB. Returns the updated profile |

## How it works (good for your video)
- Only `BlobStorageService` knows about Azure. The website will only ever call the API.
- The file type is decided by reading the file's first bytes, not its name, so a renamed `.exe` is rejected. Only JPG, PNG, WEBP.
- Each upload gets a random name (`events/{id}/{guid}.png`). The old image is deleted when one is replaced.
- The container is created on first upload, with public read so the browser can show images directly.
- If storage is down or not set up, only the upload endpoints return a friendly 503. Everything else keeps working. The real reason is written to the API's console log.

## Troubleshooting
- **503 on upload:** read the API console output. "Connection refused" means Azurite is not running. "Allow Blob anonymous access" means step B2 was skipped.
- **Image URL opens but is blank/forbidden:** the container is private. Enable anonymous access (B2), delete the container in the portal and upload again.
- **NuGet can't find `Azure.Storage.Blobs 12.22.2`:** run `dotnet add package Azure.Storage.Blobs` to get the latest 12.x.
- This code is syntax-checked only. I could not compile it here.
