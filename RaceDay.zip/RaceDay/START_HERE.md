# RaceDay - start here

This folder holds the whole project: the API (Part 2) and the MVC website (Part 3) in one solution.

1. **Database:** in SSMS, run `docs/RACEDAY_Part3_Update.sql` once. Keep `RACEDAY_DATABASE.sql` as the original build script.
2. **API settings:** open `RaceDay.API/appsettings.json` and replace `YOUR_SQL_SERVER_INSTANCE` with your SQL Server name.
3. **Image storage (only needed for uploads):** start Azurite with
   `docker run -d --name azurite -p 10000:10000 mcr.microsoft.com/azure-storage/azurite azurite-blob --blobHost 0.0.0.0 --skipApiVersionCheck`
   Real Azure steps are in `docs/CHANGES_chunk2_azure.md`.
4. **Open `RaceDay.sln`** in Visual Studio (File > Open > Project/Solution).
5. **Run both apps together:** right-click the solution > *Configure Startup Projects* > *Multiple startup projects* > set **RaceDay.API** and **RaceDay.Web** to *Start* > OK, then press the green play button.
   - API Swagger: https://localhost:61424/swagger
   - Website: https://localhost:61500
6. What each chunk changed: the `docs/CHANGES_chunk*.md` files.
